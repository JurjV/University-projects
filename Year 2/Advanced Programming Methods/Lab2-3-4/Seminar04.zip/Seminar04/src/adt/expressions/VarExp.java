package adt.expressions;

import adt.structures.MyIDictionary;
import adt.values.Value;
import controller.MyException;

public class VarExp implements IExp {
    String id;

    public VarExp(String id) {
        this.id = id;
    }

    @Override
    public String toString(){
        return id;
    }

    @Override
    public Value eval(MyIDictionary<String, Value> tbl) throws MyException {
        return tbl.lookUp(id);
    }
}
