package adt.expressions;

import adt.structures.MyIDictionary;
import adt.values.Value;
import controller.MyException;

public class ValueExp implements IExp {
    Value value;

    public ValueExp(Value value) {
        this.value = value;
    }

    @Override
    public String toString(){
        return value.toString();
    }

    @Override
    public Value eval(MyIDictionary<String, Value> tbl) throws MyException {
        return value;
    }
}
