package adt.values;

import adt.types.IType;

public interface Value {
    IType getType();

    boolean equals(Value anotherValue);
}
