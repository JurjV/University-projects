import view.Interpreter;
import view.View;

public class Main {
    public static void main(String[] args) {
        Interpreter.run();
//        View view=new View();
//        view.run();
    }
}